import React, { Component } from "react";
import '../css/Faq.css';

class Faq extends Component {
  render() {
    return (
      <div className = "container"> 
        <div className="containerFaq">
            FAQ
        </div>
      </div>
    );
  }
}

export default Faq;