import React, { Component } from "react";
import '../css/About.css';

class About extends Component {
  render() {
    return (
        <div> 
            ABOUT
        </div>
    );
  }
}

export default About;